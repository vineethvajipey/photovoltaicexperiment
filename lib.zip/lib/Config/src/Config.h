#define CONFIG_CONNECTION_STRING "HostName=enee101.azure-devices.net;SharedAccessKeyName=iothubowner;SharedAccessKey=dA0+Nj6+xbm10XbZJvif0cp3fOdAYcqkRTEC4+ESJSA="
#define CONFIG_WIFI_NAME "superwifi"
#define CONFIG_WIFI_PASSWORD "venvalvinvik"
